from collections import namedtuple

from flask import g
from flask import escape
from flask import render_template
from flask import request

from voyager.db import get_db, execute
from voyager.validate import validate_field, render_errors
from voyager.validate import NAME_RE, INT_RE, DATE_RE

def sailors(conn):
    command = f"select * from sailors;"
    return execute(conn, command)

def sailors_who_sailed_boat(conn, boat_name):
    command = f"select s.name from sailors as s, voyages as v, boats as b where v.bid=b.bid and v.sid=s.sid and b.name = '{boat_name}' group by s.sid;"
    return execute(conn, command)

def add_sailors(conn, sailor_name, sailor_age, sailor_experience):
    command = f"insert into sailors(name, age, experience) values ('{sailor_name}', '{sailor_age}', '{sailor_experience}');"
    return execute(conn, command)

def views(bp):

    @bp.route("/sailors")
    def _sailors():
        with get_db() as conn:
            rows = sailors(conn)
        return render_template("table.html", name="sailors", rows=rows)

    @bp.route("/sailors/who-sailed", methods = ['POST'])
    def _sailors_who_sailed_boat():
        with get_db() as conn:
            boat_name = request.form['boat-name']
            rows = sailors_who_sailed_boat(conn, boat_name)
        return render_template("table.html", name=f"sailors who sailed boat {boat_name}", rows=rows)

    @bp.route("/sailors/add", methods = ['POST'])
    def _add_sailor():
        with get_db() as conn:
            sailor_name = request.form['sailor-name']
            sailor_age = request.form['sailor-age']
            sailor_experience = request.form['sailor-experience']
            add_sailors(conn, sailor_name, sailor_age, sailor_experience)
            rows = sailors(conn)
        return render_template("table.html", name="Sailors", rows=rows)
