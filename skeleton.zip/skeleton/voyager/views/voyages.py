from collections import namedtuple

from flask import render_template
from flask import request

from voyager.db import get_db, execute

def voyages(conn):
    command = "select * from voyages;"
    #command = f"create table voyages (sid INTEGER NOT NULL,bid INTEGER NOT NULL,date_of_voyage DATE NOT NULL,PRIMARY KEY(sid, bid, date_of_voyage));"
    #command = f"insert into voyages (sid, bid, date_of_voyage) VALUES (1, 1, '2020-02-01'),(1, 2, '2020-02-02'),(1, 3, '2020-02-03'),(2, 1, '2020-02-02'), (2, 1, '2020-02-03'),(3, 3, '2020-02-01');"
    #command = f"drop table Voyages;"
    return execute(conn, command)

def sailors_sailed_date(conn, date):
    command = f"select s.name from sailors as s, voyages as v where v.sid=s.sid and v.date_of_voyage = '{date}' group by s.sid;"
    return execute(conn, command)

def add_voyage(conn, voyage_sid, voyage_bid, voyage_date):
    command = f"insert into voyages(sid, bid, date_of_voyage) values ('{voyage_sid}', '{voyage_bid}', '{voyage_date}');"
    return execute(conn, command)

def views(bp):
    @bp.route("/voyages")
    def _voyages():
        with get_db() as conn:
            rows = voyages(conn)
        return render_template("table.html", name="voyages", rows=rows)

    @bp.route("/sailors/who-sailed-on-date", methods = ['POST'])
    def _sailors_sailed_date():
        with get_db() as conn:
            date = request.form['date']
            rows = sailors_sailed_date(conn, date)
        return render_template("table.html", name=f"sailors who sailed on date {date}", rows=rows)
    
    @bp.route("/voyages/add", methods = ['POST'])
    def _add_voyage():
        with get_db() as conn:
            voyage_sid = request.form['voyage-sid']
            voyage_bid = request.form['voyage-bid']
            voyage_date = request.form['date']
            add_voyage(conn, voyage_sid, voyage_bid, voyage_date)
            rows = voyages(conn)
        return render_template("table.html", name="Voyages", rows=rows)
    
    

