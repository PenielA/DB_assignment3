
from collections import namedtuple

from flask import render_template
from flask import request
from flask import escape

from voyager.db import get_db, execute
def boats(conn):
    command = "select * from boats;"
    return execute(conn, command)

def boats_sailed_by(conn, sailorname):
    command = f"select b.name from sailors as s, voyages as v, boats as b where v.sid=s.sid and v.bid=b.bid and s.name = '{sailorname}' group by b.bid;"
    return execute(conn, command)

def sailors_boat_of_color(conn, color):
    command = f"select s.name from sailors as s, voyages as v, boats as b where v.bid=b.bid and v.sid=s.sid and b.color = '{color}' group by s.sid;"
    return execute(conn, command)

def boats_by_popularity(conn):
    command = f"select v.bid, count(v.bid) mycount from voyages as v, boats as b where v.bid=b.bid group by b.name order by mycount DESC;"
    return execute(conn, command)

def add_boat(conn, boat_name, boat_color):
    command = f"insert into boats(name, color) values ('{boat_name}', '{boat_color}');"
    return execute(conn, command)

def views(bp):
    @bp.route("/boats")
    def _boats():
        with get_db() as conn:
            rows = boats(conn)
        return render_template("table.html", name="boats", rows=rows)
    
    @bp.route("/boats/sailed-by", methods = ['POST'])
    def _boats_sailed_by():
        with get_db() as conn:
            sailorname = request.form['sailor-name']
            rows = boats_sailed_by(conn, sailorname)
        return render_template("table.html", name=f"boats sailed by {sailorname}", rows=rows)
    
    @bp.route("/sailors/who-sailed-on-boat-of-color", methods = ['POST'])
    def _sailors_boat_of_color():
        with get_db() as conn:
            color = request.form['color']
            rows = sailors_boat_of_color(conn, color)
        return render_template("table.html", name=f"sailors who sailed on boat of color {color}", rows=rows)

    @bp.route("/boats/by-popularity")
    def _boats_by_popularity():
        with get_db() as conn:
            rows = boats_by_popularity(conn)
        return render_template("table.html", name=f"boats by popularity", rows=rows)

    @bp.route("/boats/add", methods = ['POST'])
    def _add_boat():
        with get_db() as conn:
            boat_name = request.form['boat-name']
            boat_color = request.form['color']
            add_boat(conn, boat_name, boat_color)
            rows = boats(conn)
        return render_template("table.html", name="Boats", rows=rows)

    