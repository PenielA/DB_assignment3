#!/bin/bash
source env/bin/activate
export FLASK_APP=voyager
export FLASK_ENV=development
